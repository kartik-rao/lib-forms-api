(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/invite.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/invite.ts":
/*!***********************!*\
  !*** ./src/invite.ts ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./invite.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const AWS = __importStar(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const DBClusterId = process.env.dbClusterArn;
const DBSecretARN = process.env.dbClusterSecretArn;
const ServiceName = process.env.serviceName;
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
/**
"custom:region": "ap-southeast-2",
"sub": "51538dda-c557-49d7-b8b4-d28650ba2c92",
"cognito:groups": "AccountAdmin",
"email_verified": "true",
"iss": "https://cognito-idp.ap-southeast-2.amazonaws.com/ap-southeast-2_Cnjjlmsxh",
"custom:group": "AccountAdmin",
"cognito:username": "51538dda-c557-49d7-b8b4-d28650ba2c92",
"given_name": "John",
"custom:tenantName": "Doe Corp",
"custom:tenantId": "d823522d-62a9-4bdb-b6d2-bfdc5db3499a",
"aud": "5uh5s9bfv5m9gk7ndt9e718da6",
"event_id": "c5685688-4963-11e9-b147-11ca7af91d44",
"token_use": "id",
"auth_time": "1552902847",
"exp": "Tue Mar 19 03:03:45 UTC 2019",
"iat": "Tue Mar 19 02:03:45 UTC 2019",
"family_name": "Doe",
"custom:environment": "dev",
"email": "john.doe@mailinator.com"
*/
exports.handle = (event, context, callback) => __awaiter(this, void 0, void 0, function* () {
    const rds = new AWS.RDSDataService();
    console.log(`${ServiceName} - invite.handle - initialize`, JSON.stringify(event.requestContext));
    if (!event.requestContext.authorizer || !event.requestContext.authorizer.claims) {
        console.error(new Error("NoAuth"));
        callback(null, { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden" }) });
        return;
    }
    let claims = event.requestContext.authorizer.claims;
    console.log(`${ServiceName} - invite.handle - auth claims`, JSON.stringify(claims));
    if (claims["custom:group"] != 'AccountAdmin') {
        console.error(new Error("InvalidAuthData"));
        callback(null, { statusCode: 401, headers: CORS_HEADERS, body: JSON.stringify({ message: "Unauthorized" }) });
        return;
    }
    let poolId;
    let region = claims["custom:region"];
    let matches = claims.iss.match(new RegExp(`\/(${region}.*)`));
    // TODO: Match iss with userPoolId in process.env
    if (matches && matches.length > 0) {
        poolId = matches[1];
    }
    else {
        console.error(new Error("MissingPoolId"));
        callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": "Invalid configuration" }) });
        return;
    }
    let payload;
    try {
        payload = JSON.parse(event.body);
        console.log(`${ServiceName} - invite.handle - payload`, payload);
    }
    catch (error) {
        console.error(error);
        callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": "Invalid payload" }) });
        return;
    }
    if (claims["sub"] != payload["custom:source"]) {
        console.warn(`${ServiceName} - invite.handle - payload["custom:source"] did not match claims["sub"]`);
    }
    let accountId = claims["custom:tenantId"];
    let group = payload["custom:group"];
    if (group == 'Admin') {
        group = 'AccountAdmin';
    }
    let ownerId = claims["sub"];
    if (!payload.email || !payload.given_name || !payload.family_name || !group) {
        console.error(new Error("InvalidPayload"));
        callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": "Invalid payload" }) });
    }
    else {
        const checkUserEmailSQL = {
            database: ServiceName,
            resourceArn: DBClusterId,
            secretArn: DBSecretARN,
            sql: `SELECT COUNT(*) AS num_existing FROM User WHERE email=:email`,
            parameters: [
                { name: "email", value: { stringValue: payload["email"] } }
            ]
        };
        console.log(`${ServiceName} - invite.handle - rds-checkEmailInUse REQ`);
        let countResponse = yield rds.executeStatement(checkUserEmailSQL).promise();
        console.log(`${ServiceName} - invite.handle - rds-checkEmailInUse RES`, JSON.stringify(countResponse.records));
        if (countResponse.records[0][0]['longValue'] > 0) {
            console.error(new Error("EmailAlreadyExists"));
            callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": "EmailAlreadyExists" }) });
            return;
        }
        let userPool = new AWS.CognitoIdentityServiceProvider();
        let createUserRequest = {
            UserPoolId: poolId,
            UserAttributes: [
                { Name: "custom:group", Value: group },
                { Name: "custom:source", Value: ownerId },
                { Name: "given_name", Value: payload.given_name },
                { Name: "family_name", Value: payload.family_name },
                { Name: "custom:region", Value: process.env.region },
                { Name: "custom:tenantName", Value: claims["custom:tenantName"] },
                { Name: "custom:environment", Value: process.env.environment },
                { Name: "custom:tenantId", Value: accountId },
                { Name: "email", Value: payload.email },
                { Name: "email_verified", Value: "True" }
            ],
            DesiredDeliveryMediums: ["EMAIL"],
            Username: payload.email
        };
        if (payload.phone_number) {
            createUserRequest.UserAttributes.push({ Name: "phone_number", Value: payload.phone_number });
        }
        if (event.queryStringParameters && event.queryStringParameters["resend"] == "1") {
            createUserRequest.MessageAction = "RESEND";
        }
        console.log(`${ServiceName} - invite.handle - cognito-idp REQ`, createUserRequest);
        try {
            let timestamp = new Date().toISOString();
            let createUserResponse = yield userPool.adminCreateUser(createUserRequest).promise();
            console.log(`${ServiceName} - invite.handle - cognito-idp RES`, createUserResponse);
            let cognitoSetGroupParams = {
                GroupName: group,
                UserPoolId: poolId,
                Username: createUserResponse.User.Username
            };
            yield userPool.adminAddUserToGroup(cognitoSetGroupParams).promise();
            console.log(`${ServiceName} - invite.handle - RDS.Insert User`);
            const addUserSQL = {
                database: ServiceName,
                resourceArn: DBClusterId,
                secretArn: DBSecretARN,
                sql: `INSERT INTO User(id, ownerId, userGroup, accountId, email, phone_number, given_name, family_name, createdAt)
                    VALUES(:id, :ownerId, :userGroup, :accountId, :email, :phone_number, :given_name, :family_name, :createdAt)`,
                parameters: [
                    { name: "id", value: { stringValue: createUserResponse.User.Username } },
                    { name: "ownerId", value: { stringValue: ownerId } },
                    { name: "userGroup", value: { stringValue: group } },
                    { name: "accountId", value: { stringValue: accountId } },
                    { name: "email", value: { stringValue: payload["email"] } },
                    { name: "phone_number", value: payload.phone_number ? { stringValue: payload["phone_number"] } : { isNull: true } },
                    { name: "given_name", value: { stringValue: payload["given_name"] || null } },
                    { name: "family_name", value: { stringValue: payload["family_name"] } },
                    { name: "createdAt", value: { stringValue: timestamp } }
                ]
            };
            yield rds.executeStatement(addUserSQL).promise();
            callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify(createUserResponse) });
        }
        catch (error) {
            console.log(`${ServiceName} - invite.handle - cognito-idp RES`, error.message);
            callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: error.toString() }) });
        }
    }
});


/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ })

/******/ })));
//# sourceMappingURL=invite.js.map