(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/authftp.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./functions/authftp.ts":
/*!******************************!*\
  !*** ./functions/authftp.ts ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./authftp.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const aws_sdk_1 = __importDefault(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const aws_xray_sdk_1 = __importDefault(__webpack_require__(/*! aws-xray-sdk */ "aws-xray-sdk"));
const AWS = aws_xray_sdk_1.default.captureAWS(aws_sdk_1.default);
const short_uuid_1 = __importDefault(__webpack_require__(/*! short-uuid */ "short-uuid"));
const uuidTranslator = short_uuid_1.default();
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
const ServiceName = process.env.serviceName;
const UserPoolId = process.env.userPoolId;
const UserPoolClientId = process.env.userPoolAdminClientId;
const S3Bucket = process.env.s3_user_bucket;
const SftpRoleArn = process.env.sftp_role_arn;
const SftpServerId = process.env.sftp_server_id;
const readOnlyActions = ["s3:GetObject", "s3:GetObjectVersion"];
const allActions = ["s3:DeleteObjectVersion", "s3:PutObject", "s3:DeleteObject"].concat(readOnlyActions);
const groupActionsMap = {
    "AccountAdmin": readOnlyActions,
    "AccountEditor": readOnlyActions,
    "AccountViewer": readOnlyActions,
    "Admin": allActions
};
const attributeListToMap = (attrs) => {
    let attributes = {};
    attrs.forEach((a) => {
        attributes[a.Name] = a.Value;
    });
    return attributes;
};
const getPolicyResponse = (tenantId, group) => {
    let homeDirectory = group == "Admin" ? `/${S3Bucket}/home/` : `/${S3Bucket}/home/${tenantId}/`;
    let listBucketCondition = group == "Admin" ? "" : `,
    "Condition": {
        "StringLike": {
            "s3:prefix": [
                "home/${tenantId}/*",
                "home/${tenantId}"
            ]
        }
    }`;
    return {
        body: JSON.stringify({
            Role: SftpRoleArn,
            Policy: `{
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "AllowListingOfUserFolder",
                        "Action": [
                            "s3:ListBucket"
                        ],
                        "Effect": "Allow",
                        "Resource": [
                            "arn:aws:s3:::\${transfer:HomeBucket}"
                        ]
                        ${listBucketCondition}
                    },
                    {
                        "Sid": "AWSTransferRequirements",
                        "Effect": "Allow",
                        "Action": [
                            "s3:ListAllMyBuckets",
                            "s3:GetBucketLocation"
                        ],
                        "Resource": "*"
                    },
                    {
                        "Sid": "HomeDirObjectAccess",
                        "Effect": "Allow",
                        "Action": ${JSON.stringify(groupActionsMap[group])},
                        "Resource": "arn:aws:s3:::\${transfer:HomeDirectory}*"
                     }
                ]
            }`,
            HomeBucket: S3Bucket,
            HomeDirectory: homeDirectory
        }),
        statusCode: 200
    };
};
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`${ServiceName} - authftp.handle - initialize - head=[${JSON.stringify(event.headers || {})}] path=[${JSON.stringify(event.pathParameters || {})}] query=[${JSON.stringify(event.queryStringParameters || {})}]`);
    let { serverId, username } = event.pathParameters;
    username = uuidTranslator.toUUID(username);
    let password = event.headers.Password;
    if (SftpServerId != serverId) {
        callback(null, { body: JSON.stringify({ message: "UnauthorizedResource" }), statusCode: 200, headers: CORS_HEADERS });
        return;
    }
    const authenticationData = {
        Username: username,
        Password: password
    };
    console.log(`${ServiceName} - authftp.handle - initialize - [${username}] [${serverId}]`);
    let userPool = new AWS.CognitoIdentityServiceProvider();
    try {
        yield userPool.adminInitiateAuth({
            AuthFlow: "ADMIN_NO_SRP_AUTH",
            ClientId: UserPoolClientId,
            UserPoolId: UserPoolId,
            AuthParameters: { USERNAME: authenticationData.Username, PASSWORD: authenticationData.Password }
        }).promise();
        let user = yield userPool.adminGetUser({ UserPoolId: UserPoolId, Username: authenticationData.Username }).promise();
        let attributes = attributeListToMap(user.UserAttributes);
        const tenantId = attributes["custom:tenantId"];
        const group = attributes["custom:group"];
        if (!group || !groupActionsMap[group] || (group !== "Admin" && !tenantId)) {
            callback(null, { body: JSON.stringify({ message: "InvalidTenantOrGroup" }), statusCode: 200, headers: CORS_HEADERS });
            return;
        }
        console.log("${ServiceName} - authftp.handle - response", JSON.stringify(getPolicyResponse(tenantId, group)));
        callback(null, getPolicyResponse(tenantId, group));
    }
    catch (error) {
        console.log(`${ServiceName} - authftp.handle - user.initiateAuth ERROR - ${error.message}`);
        callback(null, { body: JSON.stringify({ message: "AuthError" }), statusCode: 200, headers: CORS_HEADERS });
    }
});


/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "aws-xray-sdk":
/*!*******************************!*\
  !*** external "aws-xray-sdk" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),

/***/ "short-uuid":
/*!*****************************!*\
  !*** external "short-uuid" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("short-uuid");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ })

/******/ })));
//# sourceMappingURL=authftp.js.map