(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/postconfirmation.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./functions/postconfirmation.ts":
/*!***************************************!*\
  !*** ./functions/postconfirmation.ts ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./postconfirmation.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const aws_sdk_1 = __importDefault(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const aws_xray_sdk_1 = __importDefault(__webpack_require__(/*! aws-xray-sdk */ "aws-xray-sdk"));
const AWS = aws_xray_sdk_1.default.captureAWS(aws_sdk_1.default);
const uuid = __webpack_require__(/*! uuid/v4 */ "uuid/v4");
const DBClusterArn = process.env.dbClusterArn;
const DBSecretARN = process.env.dbClusterSecretArn;
const ServiceName = process.env.serviceName;
const DatabaseName = process.env.databaseName;
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    console.log(`${ServiceName} - postconfirmation.handle`, event);
    const cognitoReq = event.request;
    const { userAttributes } = cognitoReq;
    const rds = new AWS.RDSDataService();
    let source = userAttributes["custom:source"];
    let userId = userAttributes.sub;
    let userPool = new AWS.CognitoIdentityServiceProvider();
    const rdsCommonParams = {
        database: DatabaseName,
        resourceArn: DBClusterArn,
        secretArn: DBSecretARN
    };
    if (!source) {
        // New Account Sign up
        // 1. Create Account with name as tenant + Create user with id as cognito sub
        let tenantName = userAttributes["custom:tenantName"];
        let accountId = uuid();
        let group = 'AccountAdmin';
        console.log(`${ServiceName} - New Account Flow - Init name=[${tenantName}] gen_id=[${accountId}]`);
        console.log(`${ServiceName} - New Account Flow - UserAttributes=[${JSON.stringify(userAttributes)}]`);
        let transaction = yield rds.beginTransaction(rdsCommonParams).promise();
        let { transactionId } = transaction;
        try {
            let timestamp = new Date().toISOString();
            const addAccountSQL = Object.assign(Object.assign({}, rdsCommonParams), { transactionId: transactionId, sql: `INSERT INTO Account(id, ownerId, name, createdAt) VALUES(:id, :ownerId, :name, :createdAt)`, parameters: [
                    { name: "id", value: { stringValue: accountId } },
                    { name: "ownerId", value: { stringValue: userId } },
                    { name: "name", value: { stringValue: tenantName } },
                    { name: "createdAt", value: { stringValue: timestamp } }
                ] });
            let hasPhone = !!userAttributes["phone_number"];
            const addUserSQL = Object.assign(Object.assign({}, rdsCommonParams), { transactionId: transactionId, sql: `INSERT INTO User(id, ownerId, userGroup, accountId, email, phone_number, given_name, family_name, createdAt)
                    VALUES(:id, :ownerId, :userGroup, :accountId, :email, :phone_number, :given_name, :family_name, :createdAt)`, parameters: [
                    { name: "id", value: { stringValue: userId } },
                    { name: "ownerId", value: { stringValue: userId } },
                    { name: "userGroup", value: { stringValue: group } },
                    { name: "accountId", value: { stringValue: accountId } },
                    { name: "email", value: { stringValue: userAttributes["email"] } },
                    { name: "phone_number", value: hasPhone ? { stringValue: userAttributes["phone_number"] } : { isNull: true } },
                    { name: "given_name", value: { stringValue: userAttributes["given_name"] } },
                    { name: "family_name", value: { stringValue: userAttributes["family_name"] } },
                    { name: "createdAt", value: { stringValue: timestamp } }
                ] });
            console.log(`${ServiceName} - New Account Flow - RDS Init transaction ${transactionId}`);
            yield rds.executeStatement(Object.assign(Object.assign({}, rdsCommonParams), { transactionId: transactionId, sql: "SET foreign_key_checks=0" })).promise();
            console.log(`${ServiceName} - New Account Flow - RDS.Insert User - ${JSON.stringify(addUserSQL)}`);
            yield rds.executeStatement(addUserSQL).promise();
            console.log(`${ServiceName} - New Account Flow - RDS.Insert Account - ${JSON.stringify(addAccountSQL)}`);
            yield rds.executeStatement(addAccountSQL).promise();
            yield rds.commitTransaction({ transactionId: transactionId, resourceArn: DBClusterArn, secretArn: DBSecretARN }).promise();
        }
        catch (error) {
            // TODO: We should send an SNS notification or capture this error somewhere
            console.error(`${ServiceName} - AccountAdmin initiated flow - RDS Error [${userId}]`, error);
            yield rds.rollbackTransaction({ transactionId: transactionId, resourceArn: DBClusterArn, secretArn: DBSecretARN }).promise();
            callback(error);
            return;
        }
        // 2. Set Cognito Group to Account Admin
        console.log(`${ServiceName} - New Account Flow - adminAddUserToGroup [AccountAdmin]`);
        let addUserToGroupParams = {
            GroupName: 'AccountAdmin',
            UserPoolId: event.userPoolId,
            Username: event.userName
        };
        yield userPool.adminAddUserToGroup(addUserToGroupParams).promise();
        // 3. Update user attributes
        console.log(`${ServiceName} - New Account Flow - adminUpdateUserAttributes`);
        let updateUserAttributesParams = {
            UserAttributes: [
                { Name: "custom:group", Value: addUserToGroupParams.GroupName },
                { Name: "custom:region", Value: process.env.region },
                { Name: "custom:environment", Value: process.env.environment },
                { Name: "custom:tenantName", Value: tenantName },
                { Name: "custom:tenantId", Value: accountId }
            ],
            UserPoolId: event.userPoolId,
            Username: event.userName
        };
        yield userPool.adminUpdateUserAttributes(updateUserAttributesParams).promise();
        callback(null, event);
    }
    else {
        // AccountAdmin initiated signup
        let group = userAttributes["custom:group"];
        if (group == 'Admin') {
            // Do not allow Admin as a group
            group = 'AccountAdmin';
        }
        // Owner's sub is in the source
        console.log(`${ServiceName} - AccountAdmin initiated flow - Init userId=[${userId}] group=[${group}]`);
        let accountAdmin;
        try {
            console.log(`${ServiceName} - AccountAdmin initiated flow - ${source}`);
            accountAdmin = yield userPool.adminGetUser({
                UserPoolId: event.userPoolId, Username: source
            }).promise();
            let accountId = accountAdmin.UserAttributes["custom:tenantId"];
            if (!accountId) {
                let err = new Error("InvalidUserCreateRequest");
                console.error(`${ServiceName} - Invalid user, no tenant on AccountAdmin`, err);
                throw err;
            }
            console.log(`${ServiceName} - AccountAdmin initiated flow - RDS.Insert user=[${userId}] tenant=[${accountId}] group=[${group}]`);
            const addUserSQL = {
                database: DatabaseName,
                resourceArn: DBClusterArn,
                secretArn: DBSecretARN,
                sql: `INSERT INTO User(id, ownerId, userGroup, accountId, email, phone_number, given_name, family_name)
                    VALUES(:id, :ownerId, :userGroup, :accountId, :email, :phone_number, :given_name, :family_name)`,
                parameters: [
                    { name: "id", value: { stringValue: userId } },
                    { name: "ownerId", value: { stringValue: userId } },
                    { name: "userGroup", value: { stringValue: group } },
                    { name: "accountId", value: { stringValue: accountId } },
                    { name: "email", value: { stringValue: userAttributes["email"] } },
                    { name: "phone_number", value: { stringValue: userAttributes["phone_number"] } },
                    { name: "given_name", value: { stringValue: userAttributes["given_name"] } },
                    { name: "family_name", value: { stringValue: userAttributes["family_name"] } }
                ]
            };
            yield rds.executeStatement(addUserSQL).promise();
            let cognitoSetGroupParams = {
                GroupName: group,
                UserPoolId: event.userPoolId,
                Username: event.userName
            };
            console.log(`${ServiceName} - AccountAdmin initiated flow - adminAddUserToGroup username=[${event.userName}] group=[${group}]`);
            yield userPool.adminAddUserToGroup(cognitoSetGroupParams).promise();
            let cognitoUpdateAttributesParams = {
                UserPoolId: event.userPoolId,
                Username: event.userName,
                UserAttributes: [
                    { Name: "custom:group", Value: cognitoSetGroupParams.GroupName },
                    { Name: "custom:region", Value: process.env.region },
                    { Name: "custom:tenantName", Value: accountAdmin.UserAttributes["custom:tenantName"] },
                    { Name: "custom:environment", Value: process.env.environment },
                    { Name: "custom:tenantId", Value: accountId }
                ]
            };
            yield userPool.adminUpdateUserAttributes(cognitoUpdateAttributesParams).promise();
            callback(null, event);
        }
        catch (error) {
            console.error(`${ServiceName} - AccountAdmin initiated flow - Error [${userId}]`, error);
            callback(error);
        }
    }
});
/**
 * {
    "version": "1",
    "region": "eu-central-1",
    "userPoolId": "eu-central-1_45YtlkflA",
    "userName": "user4",
    "callerContext": {
        "awsSdkVersion": "aws-sdk-java-console",
        "clientId": "4736lckau64in48dku3rta0eqa"
    },
    "triggerSource": "PostConfirmation_ConfirmSignUp",
    "request": {
        "userAttributes": {
            "sub": "a2c21839-f9fc-49e3-be9a-16f5823d6705",
            "cognito:user_status": "CONFIRMED",
            "email_verified": "true",
            "email": "asdfsdfsgdfg@carbtc.net"
        }
    },
    "response": {}
}
 */ 


/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "aws-xray-sdk":
/*!*******************************!*\
  !*** external "aws-xray-sdk" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ }),

/***/ "uuid/v4":
/*!**************************!*\
  !*** external "uuid/v4" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("uuid/v4");

/***/ })

/******/ })));
//# sourceMappingURL=postconfirmation.js.map