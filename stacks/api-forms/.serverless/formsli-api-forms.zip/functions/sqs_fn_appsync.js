(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/sqs_fn_appsync.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./functions/sqs_fn_appsync.ts":
/*!*************************************!*\
  !*** ./functions/sqs_fn_appsync.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./sqs_fn_appsync.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
global['WebSocket'] = __webpack_require__(/*! ws */ "ws");
__webpack_require__(/*! es6-promise */ "es6-promise").polyfill();
__webpack_require__(/*! isomorphic-fetch */ "isomorphic-fetch");
const aws_appsync_1 = __importDefault(__webpack_require__(/*! aws-appsync */ "aws-appsync"));
const auth_link_1 = __webpack_require__(/*! aws-appsync/lib/link/auth-link */ "aws-appsync/lib/link/auth-link");
const aws_sdk_1 = __importDefault(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const aws_xray_sdk_1 = __importDefault(__webpack_require__(/*! aws-xray-sdk */ "aws-xray-sdk"));
const graphql_tag_1 = __importDefault(__webpack_require__(/*! graphql-tag */ "graphql-tag"));
const AWS = aws_xray_sdk_1.default.captureAWS(aws_sdk_1.default);
const GraphQlApiKey = process.env.graphqlApiKey;
const GraphQlUrl = process.env.graphqlApiUrl;
const Region = process.env.region;
const QueueUrl = process.env.sqs_entry_url;
const ServiceName = process.env.serviceName;
const Env = process.env.environment;
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
const isDebug = Env !== "production";
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    let entryQueue = new AWS.SQS({ region: Region });
    let firehose = new AWS.Firehose({ region: Region });
    // Set up Apollo client
    const appsync = new aws_appsync_1.default({
        url: GraphQlUrl,
        region: Region,
        auth: {
            type: auth_link_1.AUTH_TYPE.API_KEY,
            apiKey: GraphQlApiKey
        },
        disableOffline: true
    });
    const mutation = graphql_tag_1.default(`mutation AddFormEntry($input: AddFormEntryInput!) {
        addFormEntry(input: $input) {
          id
          formId
          accountId
          createdAt
        }
    }`);
    try {
        isDebug && console.log(`${ServiceName} - sqs_fn_appsync.handle - processing ${event.Records.length} entries`);
        let client = yield appsync.hydrated();
        let writeRowAndDeleteMessage = (sqsRecord) => {
            let Attributes = sqsRecord.messageAttributes;
            let Body = JSON.parse(sqsRecord.body);
            let { __RequestId } = Body;
            let FormId = Attributes.FormId.stringValue;
            let AccountId = Attributes.TenantId.stringValue;
            const variables = { input: { id: __RequestId, formId: FormId, accountId: AccountId, data: Body.Payload } };
            return Promise.all([
                client.mutate({ mutation: mutation, variables: variables }),
                entryQueue.deleteMessage({ QueueUrl: QueueUrl, ReceiptHandle: sqsRecord.receiptHandle }).promise()
            ]);
        };
        let rowPromises = event.Records.map((r) => {
            return writeRowAndDeleteMessage(r);
        });
        yield Promise.all(rowPromises);
        callback(null, { statusCode: 200, body: JSON.stringify({ message: "OK", requestId: context.requestId }) });
    }
    catch (error) {
        console.log(`${ServiceName} - sqs_fn_appsync.handle ERROR`, error);
        callback(null, { statusCode: 500, body: JSON.stringify({ message: "InternalServerError", status: 500, requestId: context.requestId }) });
    }
});


/***/ }),

/***/ "aws-appsync":
/*!******************************!*\
  !*** external "aws-appsync" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-appsync");

/***/ }),

/***/ "aws-appsync/lib/link/auth-link":
/*!*************************************************!*\
  !*** external "aws-appsync/lib/link/auth-link" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-appsync/lib/link/auth-link");

/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "aws-xray-sdk":
/*!*******************************!*\
  !*** external "aws-xray-sdk" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),

/***/ "es6-promise":
/*!******************************!*\
  !*** external "es6-promise" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("es6-promise");

/***/ }),

/***/ "graphql-tag":
/*!******************************!*\
  !*** external "graphql-tag" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),

/***/ "isomorphic-fetch":
/*!***********************************!*\
  !*** external "isomorphic-fetch" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("isomorphic-fetch");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ }),

/***/ "ws":
/*!*********************!*\
  !*** external "ws" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("ws");

/***/ })

/******/ })));
//# sourceMappingURL=sqs_fn_appsync.js.map