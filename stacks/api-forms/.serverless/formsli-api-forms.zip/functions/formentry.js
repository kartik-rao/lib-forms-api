(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/formentry.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../api-streams/functions/common.ts":
/*!******************************************!*\
  !*** ../api-streams/functions/common.ts ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const short_uuid_1 = __importDefault(__webpack_require__(/*! short-uuid */ "short-uuid"));
const uuidTranslator = short_uuid_1.default();
function getDeliveryStreamName(stage, tenantId, formId) {
    return `${stage}-stream-${uuidTranslator.fromUUID(tenantId)}-${uuidTranslator.fromUUID(formId)}`;
}
exports.getDeliveryStreamName = getDeliveryStreamName;
function getDeliveryStreamPrefix(tenantId, formId) {
    return `home/${tenantId}/${formId}/processed/`;
}
exports.getDeliveryStreamPrefix = getDeliveryStreamPrefix;
function getDeliveryStreamErrorPrefix(tenantId, formId) {
    return `home/${tenantId}/${formId}/error/`;
}
exports.getDeliveryStreamErrorPrefix = getDeliveryStreamErrorPrefix;


/***/ }),

/***/ "./functions/formentry.ts":
/*!********************************!*\
  !*** ./functions/formentry.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./formentry.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const Env = process.env.environment;
const ServiceName = process.env.databaseName;
const Region = process.env.region;
const EntryQueueUrl = process.env.sqs_entry_url;
const FirehoseQueueUrl = process.env.sqs_firehose_url;
const IntegrationQueueUrl = process.env.sqs_integration_url;
const AnalyticsQueueUrl = process.env.sqs_analytics_url;
const isDebug = Env !== "production";
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
const aws_sdk_1 = __importDefault(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const aws_xray_sdk_1 = __importDefault(__webpack_require__(/*! aws-xray-sdk */ "aws-xray-sdk"));
const AWS = aws_xray_sdk_1.default.captureAWS(aws_sdk_1.default);
const dayjs_1 = __importDefault(__webpack_require__(/*! dayjs */ "dayjs"));
const customParseFormat_1 = __importDefault(__webpack_require__(/*! dayjs/plugin/customParseFormat */ "dayjs/plugin/customParseFormat"));
const utc_1 = __importDefault(__webpack_require__(/*! dayjs/plugin/utc */ "dayjs/plugin/utc"));
dayjs_1.default.extend(utc_1.default);
dayjs_1.default.extend(customParseFormat_1.default);
const common_1 = __webpack_require__(/*! ../../api-streams/functions/common */ "../api-streams/functions/common.ts");
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    let { requestId, stage, identity, requestTime } = event.requestContext;
    let { formId, tenantId } = event.pathParameters;
    if (!event.body) {
        callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message: "BadRequest" }) });
        return;
    }
    const streamName = common_1.getDeliveryStreamName(stage, tenantId, formId);
    let attributes = {
        "Region": { DataType: "String", StringValue: Region },
        "Service": { DataType: "String", StringValue: ServiceName },
        "Stage": { DataType: "String", StringValue: stage },
        "FormId": { DataType: "String", StringValue: formId },
        "TenantId": { DataType: "String", StringValue: tenantId },
        "StreamName": { DataType: "String", StringValue: streamName }
    };
    const utcTimestamp = dayjs_1.default(requestTime, 'DD/MMM/YYYY:HH:mm:ss ZZ').utc().format();
    let queueData = {
        __RequestId: requestId,
        __RequestTimestamp: utcTimestamp,
        __RequestIpAddress: identity.sourceIp,
        __RequestUserAgent: identity.userAgent,
        Payload: event.body
    };
    if (event.queryStringParameters && event.queryStringParameters.echo) {
        callback(null, { statusCode: 201, headers: CORS_HEADERS, body: JSON.stringify(queueData) });
        return;
    }
    let sqs = new AWS.SQS({ region: Region });
    let baseMessage = { MessageBody: JSON.stringify(queueData), MessageAttributes: attributes };
    isDebug && console.log(`${ServiceName} - formentry.handle.sendMessageAsync SEND`);
    try {
        yield Promise.all([
            sqs.sendMessage(Object.assign(Object.assign({}, baseMessage), { QueueUrl: EntryQueueUrl })).promise(),
            sqs.sendMessage(Object.assign(Object.assign({}, baseMessage), { QueueUrl: FirehoseQueueUrl })).promise(),
            sqs.sendMessage(Object.assign(Object.assign({}, baseMessage), { QueueUrl: AnalyticsQueueUrl })).promise(),
            sqs.sendMessage(Object.assign(Object.assign({}, baseMessage), { QueueUrl: IntegrationQueueUrl })).promise()
        ]);
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "OK", status: 202, id: requestId, timestamp: utcTimestamp }) });
    }
    catch (error) {
        console.log(`${ServiceName} - formentry.handle ERROR - SQS.parallel`, error);
        callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "InternalServerError", status: 500, requestId: requestId }) });
    }
});


/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "aws-xray-sdk":
/*!*******************************!*\
  !*** external "aws-xray-sdk" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),

/***/ "dayjs":
/*!************************!*\
  !*** external "dayjs" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("dayjs");

/***/ }),

/***/ "dayjs/plugin/customParseFormat":
/*!*************************************************!*\
  !*** external "dayjs/plugin/customParseFormat" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("dayjs/plugin/customParseFormat");

/***/ }),

/***/ "dayjs/plugin/utc":
/*!***********************************!*\
  !*** external "dayjs/plugin/utc" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("dayjs/plugin/utc");

/***/ }),

/***/ "short-uuid":
/*!*****************************!*\
  !*** external "short-uuid" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("short-uuid");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ })

/******/ })));
//# sourceMappingURL=formentry.js.map