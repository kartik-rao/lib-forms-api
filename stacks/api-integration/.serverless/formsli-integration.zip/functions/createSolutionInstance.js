(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/createSolutionInstance.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./functions/createSolutionInstance.ts":
/*!*********************************************!*\
  !*** ./functions/createSolutionInstance.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./createIntegrationDeployment.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const gqlClient_1 = __webpack_require__(/*! ./gqlClient */ "./functions/gqlClient.ts");
const graphql_tag_1 = __importDefault(__webpack_require__(/*! graphql-tag */ "graphql-tag"));
const Env = process.env.environment;
const ServiceName = process.env.serviceName;
const VendorApiUrl = process.env.vendorApiUrl;
const VendorApiToken = process.env.vendorApiToken;
const DBClusterArn = process.env.dbClusterArn;
const DBSecretARN = process.env.dbClusterSecretArn;
const DatabaseName = process.env.databaseName;
const PartnerId = process.env.vendorAccountId;
const dataApi = __webpack_require__(/*! data-api-client */ "data-api-client")({
    secretArn: DBSecretARN,
    resourceArn: DBClusterArn,
    database: DatabaseName
});
const isDebug = Env !== "production";
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    let { requestId, stage, identity, requestTime } = event.requestContext;
    let payload;
    try {
        payload = JSON.parse(event.body);
        console.log(`${ServiceName} - invite.handle - payload`, payload);
        if (!payload.tenantId) {
            callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": "MissingPayloadAttributes" }) });
            return;
        }
    }
    catch (error) {
        console.error(error);
        callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": "Invalid payload" }) });
        return;
    }
    let { tenantId } = payload;
    isDebug && console.log(`${ServiceName} - createIntegrationDeployment.handle init`);
    if (!event.requestContext.authorizer || !event.requestContext.authorizer.claims) {
        console.error(new Error("NoAuth"));
        callback(null, { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden" }) });
        return;
    }
    let claims = event.requestContext.authorizer.claims;
    let isAdmin = claims["group"] == "Admin";
    if (claims["custom:tenantId"] !== tenantId && !isAdmin) {
        console.error(new Error("TenantMismatchError"));
        callback(null, { statusCode: 403, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden" }) });
        return;
    }
    isDebug && console.log(`${ServiceName} - createIntegrationDeployment.handle getExternalId`);
    let integrationUser;
    // Check if we have already created a tenant in the vendor
    try {
        integrationUser = yield dataApi.query({
            sql: `SELECT ac.name as 'accountName', ai.id, ai.externalId, ai.createdAt from AccountIntegration ai, Account ac WHERE ac.id = :tenantId AND ai.accountId = ac.id`,
            parameters: [
                { tenantId: tenantId }
            ]
        });
    }
    catch (error) {
        callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "GetIntegrationUserError", status: 500, requestId: requestId }) });
        return;
    }
    if (integrationUser && integrationUser.records && integrationUser.records.length > 0) {
        let vendorAdminClient = gqlClient_1.generateClient(VendorApiUrl, VendorApiToken);
        let userId = integrationUser.records[0].externalId;
        let authorizationCode, accessToken;
        try {
            // This is part of the config URL used to configure the solution
            // https://tray.io/documentation/embedded/full-api-ref/user-actions/auth-code/
            isDebug && console.log(`${ServiceName} - createIntegrationDeployment.handle generateAuthorizationCode`);
            let authCodeMutation = graphql_tag_1.default `
            mutation {
                generateAuthorizationCode(input: {userId: "${userId}"}) {
                    authorizationCode
                }
            }`;
            let codeResponse = yield vendorAdminClient.mutate({ mutation: authCodeMutation });
            authorizationCode = codeResponse.data.generateAuthorizationCode;
        }
        catch (error) {
            callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "GenerateAccessTokenError", status: 500, requestId: requestId }) });
            return;
        }
        try {
            // This is used to authorize the createSolutionInstance mutation on behalf of the tenant
            // https://tray.io/documentation/embedded/full-api-ref/user-actions/authorize-user/
            isDebug && console.log(`${ServiceName} - createIntegrationDeployment.handle requestAccessToken`);
            let accessTokenMutation = graphql_tag_1.default `
            mutation {
                authorize(input: {userId: "${userId}"}) {
                    accessToken
                }
            }`;
            let tokenResponse = yield vendorAdminClient.mutate({ mutation: accessTokenMutation });
            accessToken = tokenResponse.data.authorize.accessToken;
        }
        catch (error) {
            callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "GenerateAccessTokenError", status: 500, requestId: requestId }) });
            return;
        }
        try {
            // Create a tenant specific client
            let vendorUserClient = gqlClient_1.generateClient(VendorApiUrl, accessToken);
            // Create the solution
            // https://tray.io/documentation/embedded/full-api-ref/create-solution-instance/
            isDebug && console.log(`${ServiceName} - createIntegrationDeployment.handle createSolutionInstance`);
            let createSolutionMutation = graphql_tag_1.default `
                mutation {
                    createSolutionInstance(input: {
                        solutionId: "${payload.integrationId}",
                        instanceName: "${payload.name}",
                        configValues: [payload.configValues]
                    }) {
                        solutionInstance {
                            id
                        }
                    }
            }`;
            let instance = yield vendorUserClient.mutate({ mutation: createSolutionMutation });
            let instanceId = instance.data.createSolutionInstance.solutionInstance.id;
            callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({
                    instanceId: instanceId,
                    configUrl: `https://embedded.tray.io/external/solutions/${PartnerId}/configure/${instanceId}?code=${authorizationCode}`
                }) });
        }
        catch (error) {
            callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "CreateSolutionInstanceError", status: 500, requestId: requestId }) });
        }
    }
    else {
        callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ message: "NoIntegrationUserError", status: 400, requestId: requestId }) });
    }
});


/***/ }),

/***/ "./functions/gqlClient.ts":
/*!********************************!*\
  !*** ./functions/gqlClient.ts ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_fetch_1 = __importDefault(__webpack_require__(/*! node-fetch */ "node-fetch"));
const apollo_link_http_1 = __webpack_require__(/*! apollo-link-http */ "apollo-link-http");
const apollo_link_context_1 = __webpack_require__(/*! apollo-link-context */ "apollo-link-context");
const apollo_client_1 = __webpack_require__(/*! apollo-client */ "apollo-client");
const apollo_cache_inmemory_1 = __webpack_require__(/*! apollo-cache-inmemory */ "apollo-cache-inmemory");
const lodash_1 = __webpack_require__(/*! lodash */ "lodash");
const defaultOptions = {
    watchQuery: {
        fetchPolicy: 'network-only',
        errorPolicy: 'ignore',
    },
    query: {
        fetchPolicy: 'network-only',
        errorPolicy: 'all',
    },
};
// Create a Apollo Client Context for a given auth token:
const authLink = token => apollo_link_context_1.setContext((_, { headers }) => ({
    headers: Object.assign(Object.assign({}, headers), { authorization: `Bearer ${token}` }),
}));
// Generate an Apollo Client for a given auth token:
exports.generateClient = (gqlEndpoint, token) => {
    return new apollo_client_1.ApolloClient({
        link: authLink(token).concat(new apollo_link_http_1.HttpLink({ uri: gqlEndpoint, fetch: node_fetch_1.default })),
        cache: new apollo_cache_inmemory_1.InMemoryCache(),
        defaultOptions: defaultOptions
    });
};
// Get nodes for a given path from graphQL response:
exports.getNodesAt = (results, path) => {
    return lodash_1.map(lodash_1.values(lodash_1.get(results, path)), x => x.node);
};


/***/ }),

/***/ "apollo-cache-inmemory":
/*!****************************************!*\
  !*** external "apollo-cache-inmemory" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("apollo-cache-inmemory");

/***/ }),

/***/ "apollo-client":
/*!********************************!*\
  !*** external "apollo-client" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("apollo-client");

/***/ }),

/***/ "apollo-link-context":
/*!**************************************!*\
  !*** external "apollo-link-context" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("apollo-link-context");

/***/ }),

/***/ "apollo-link-http":
/*!***********************************!*\
  !*** external "apollo-link-http" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("apollo-link-http");

/***/ }),

/***/ "data-api-client":
/*!**********************************!*\
  !*** external "data-api-client" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("data-api-client");

/***/ }),

/***/ "graphql-tag":
/*!******************************!*\
  !*** external "graphql-tag" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),

/***/ "node-fetch":
/*!*****************************!*\
  !*** external "node-fetch" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("node-fetch");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ })

/******/ })));
//# sourceMappingURL=createSolutionInstance.js.map