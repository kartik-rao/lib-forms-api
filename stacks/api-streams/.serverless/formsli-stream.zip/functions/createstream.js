(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/createstream.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../node_modules/any-base/index.js":
/*!*******************************************************************************************!*\
  !*** /Users/kartik/Development/Repositories/lib-forms-api/node_modules/any-base/index.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Converter = __webpack_require__(/*! ./src/converter */ "../../node_modules/any-base/src/converter.js");

/**
 * Function get source and destination alphabet and return convert function
 *
 * @param {string|Array} srcAlphabet
 * @param {string|Array} dstAlphabet
 *
 * @returns {function(number|Array)}
 */
function anyBase(srcAlphabet, dstAlphabet) {
    var converter = new Converter(srcAlphabet, dstAlphabet);
    /**
     * Convert function
     *
     * @param {string|Array} number
     *
     * @return {string|Array} number
     */
    return function (number) {
        return converter.convert(number);
    }
};

anyBase.BIN = '01';
anyBase.OCT = '01234567';
anyBase.DEC = '0123456789';
anyBase.HEX = '0123456789abcdef';

module.exports = anyBase;

/***/ }),

/***/ "../../node_modules/any-base/src/converter.js":
/*!***************************************************************************************************!*\
  !*** /Users/kartik/Development/Repositories/lib-forms-api/node_modules/any-base/src/converter.js ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Converter
 *
 * @param {string|Array} srcAlphabet
 * @param {string|Array} dstAlphabet
 * @constructor
 */
function Converter(srcAlphabet, dstAlphabet) {
    if (!srcAlphabet || !dstAlphabet || !srcAlphabet.length || !dstAlphabet.length) {
        throw new Error('Bad alphabet');
    }
    this.srcAlphabet = srcAlphabet;
    this.dstAlphabet = dstAlphabet;
}

/**
 * Convert number from source alphabet to destination alphabet
 *
 * @param {string|Array} number - number represented as a string or array of points
 *
 * @returns {string|Array}
 */
Converter.prototype.convert = function(number) {
    var i, divide, newlen,
    numberMap = {},
    fromBase = this.srcAlphabet.length,
    toBase = this.dstAlphabet.length,
    length = number.length,
    result = typeof number === 'string' ? '' : [];

    if (!this.isValid(number)) {
        throw new Error('Number "' + number + '" contains of non-alphabetic digits (' + this.srcAlphabet + ')');
    }

    if (this.srcAlphabet === this.dstAlphabet) {
        return number;
    }

    for (i = 0; i < length; i++) {
        numberMap[i] = this.srcAlphabet.indexOf(number[i]);
    }
    do {
        divide = 0;
        newlen = 0;
        for (i = 0; i < length; i++) {
            divide = divide * fromBase + numberMap[i];
            if (divide >= toBase) {
                numberMap[newlen++] = parseInt(divide / toBase, 10);
                divide = divide % toBase;
            } else if (newlen > 0) {
                numberMap[newlen++] = 0;
            }
        }
        length = newlen;
        result = this.dstAlphabet.slice(divide, divide + 1).concat(result);
    } while (newlen !== 0);

    return result;
};

/**
 * Valid number with source alphabet
 *
 * @param {number} number
 *
 * @returns {boolean}
 */
Converter.prototype.isValid = function(number) {
    var i = 0;
    for (; i < number.length; ++i) {
        if (this.srcAlphabet.indexOf(number[i]) === -1) {
            return false;
        }
    }
    return true;
};

module.exports = Converter;

/***/ }),

/***/ "../../node_modules/short-uuid/index.js":
/*!*********************************************************************************************!*\
  !*** /Users/kartik/Development/Repositories/lib-forms-api/node_modules/short-uuid/index.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Created by Samuel on 6/4/2016.
 * Simple wrapper functions to produce shorter UUIDs for cookies, maybe everything?
 */

var anyBase = __webpack_require__(/*! any-base */ "../../node_modules/any-base/index.js");
var uuidV4 = __webpack_require__(/*! uuid/v4 */ "uuid/v4");

var flickrBase58 = '123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
var cookieBase90 = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&'()*+-./:<=>?@[]^_`{|}~";

var toFlickr;

/**
 * Takes a UUID, strips the dashes, and translates.
 * @param {string} longId
 * @param {function(string)} translator
 * @returns {string}
 */
function shortenUUID (longId, translator) {
    return translator(longId.toLowerCase().replace(/-/g,''));
}

/**
 * Translate back to hex and turn back into UUID format, with dashes
 * @param {string} shortId
 * @param {function(string)} translator
 * @returns {string}
 */
function enlargeUUID(shortId, translator) {
    var uu1 = translator(shortId);
    var leftPad = "";
    var m;

    // Pad out UUIDs beginning with zeros (any number shorter than 32 characters of hex)
    for (var i = 0, len = 32-uu1.length; i < len; ++i) {
        leftPad += "0";
    }

    // Join the zero padding and the UUID and then slice it up with match
    m = (leftPad + uu1).match(/(\w{8})(\w{4})(\w{4})(\w{4})(\w{12})/);

    // Accumulate the matches and join them.
    return [m[1], m[2], m[3], m[4], m[5]].join('-');
}

module.exports = (function(){

    /**
     * @constructor
     * @param {string?} toAlphabet - Defaults to flickrBase58 if not provided
     * @returns {{new: (function()),
     *  uuid: (function()),
     *  fromUUID: (function(string)),
     *  toUUID: (function(string)),
     *  alphabet: (string)}}
     */
    function MakeConvertor(toAlphabet) {

        // Default to Flickr 58
        var useAlphabet = toAlphabet || flickrBase58;

        // UUIDs are in hex, so we translate to and from.
        var fromHex = anyBase(anyBase.HEX, useAlphabet);
        var toHex = anyBase(useAlphabet, anyBase.HEX);
        var generate = function() { return shortenUUID(uuidV4(), fromHex); };

        return {
            new: generate,
            generate: generate,
            uuid: uuidV4,
            fromUUID: function(uuid) { return shortenUUID(uuid, fromHex); },
            toUUID: function(shortUuid) { return enlargeUUID(shortUuid, toHex); },
            alphabet: useAlphabet
        };
    }

    // Expose the constants for other purposes.
    MakeConvertor.constants = {
        flickrBase58: flickrBase58,
        cookieBase90: cookieBase90
    };

    // Expose the generic v4 UUID generator for convenience
    MakeConvertor.uuid = uuidV4;

    // Provide a generic generator
    MakeConvertor.generate = function() {
        if (!toFlickr) {
            // Generate on first use;
            toFlickr = anyBase(anyBase.HEX, flickrBase58);
        }
        return shortenUUID(uuidV4(), toFlickr);
    };

    return MakeConvertor;
}());


/***/ }),

/***/ "./functions/common.ts":
/*!*****************************!*\
  !*** ./functions/common.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const short_uuid_1 = __importDefault(__webpack_require__(/*! short-uuid */ "../../node_modules/short-uuid/index.js"));
const uuidTranslator = short_uuid_1.default();
function getDeliveryStreamName(stage, tenantId, formId) {
    return `${stage}-stream-${uuidTranslator.fromUUID(tenantId)}-${uuidTranslator.fromUUID(formId)}`;
}
exports.getDeliveryStreamName = getDeliveryStreamName;
function getDeliveryStreamPrefix(tenantId, formId) {
    return `home/${tenantId}/${formId}/processed/`;
}
exports.getDeliveryStreamPrefix = getDeliveryStreamPrefix;
function getDeliveryStreamErrorPrefix(tenantId, formId) {
    return `home/${tenantId}/${formId}/error/`;
}
exports.getDeliveryStreamErrorPrefix = getDeliveryStreamErrorPrefix;


/***/ }),

/***/ "./functions/createstream.ts":
/*!***********************************!*\
  !*** ./functions/createstream.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./createstream.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const aws_sdk_1 = __importDefault(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const aws_xray_sdk_1 = __importDefault(__webpack_require__(/*! aws-xray-sdk */ "aws-xray-sdk"));
const common_1 = __webpack_require__(/*! ./common */ "./functions/common.ts");
const AWS = aws_xray_sdk_1.default.captureAWS(aws_sdk_1.default);
const Region = process.env.region;
const ServiceName = process.env.serviceName;
const UserBucket = process.env.s3_user_bucket;
const RoleArn = process.env.kinesisAccessRole;
const DBClusterId = process.env.dbClusterArn;
const DBSecretARN = process.env.dbClusterSecretArn;
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    if (!event.requestContext.authorizer || !event.requestContext.authorizer.claims) {
        console.error(new Error("NoAuth"));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "Unauthorized", status: 401 }) });
        return;
    }
    let claims = event.requestContext.authorizer.claims;
    console.log(`${ServiceName} - createstream.handle - auth claims`, JSON.stringify(claims));
    let group = claims["custom:group"];
    if (!group || group.length == 0) {
        console.error(new Error("NoGroup"));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden", status: 403 }) });
        return;
    }
    if (!(group == "AccountEditor" || group == "Admin" || group == "AccountAdmin")) {
        console.error(new Error(`Group ${group} is not authorized to create stream`));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden", status: 403 }) });
        return;
    }
    let tenantId = group == "Admin" ? event.queryStringParameters.tenantId : claims["custom:tenantId"];
    if (!tenantId) {
        console.error(new Error(`NoTenantId`));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "BadRequest", status: 400 }) });
        return;
    }
    let { requestId, stage, requestTime } = event.requestContext;
    let { formId } = event.pathParameters;
    try {
        const rds = new AWS.RDSDataService();
        const checkFormInTenant = {
            database: ServiceName,
            resourceArn: DBClusterId,
            secretArn: DBSecretARN,
            sql: `SELECT COUNT(*) AS form_count FROM Form WHERE id=:id AND accountId=:accountId`,
            parameters: [
                { name: "id", value: { stringValue: formId } },
                { name: "accountId", value: { stringValue: tenantId } },
            ]
        };
        console.log(`${ServiceName} - createstream.handle - rds-checkForm REQ`);
        let countResponse = yield rds.executeStatement(checkFormInTenant).promise();
        console.log(`${ServiceName} - createstream.handle - rds-checkForm RES`, JSON.stringify(countResponse.records));
        if (countResponse.records[0][0]['longValue'] == 0) {
            console.error(new Error("InvalidFormId"));
            callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": `Form [${formId}] not found in tenant [${tenantId}]` }) });
            return;
        }
    }
    catch (error) {
        console.error(error);
        callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "InternalServerError" }) });
    }
    let firehose = new AWS.Firehose({ region: Region });
    const streamName = common_1.getDeliveryStreamName(stage, tenantId, formId);
    const streamPrefix = common_1.getDeliveryStreamPrefix(tenantId, formId);
    const streamErrorPrefix = common_1.getDeliveryStreamErrorPrefix(tenantId, formId);
    try {
        let streams = yield firehose.listDeliveryStreams({ ExclusiveStartDeliveryStreamName: streamName }).promise();
        if (!streams.DeliveryStreamNames || streams.DeliveryStreamNames.length == 0) {
            yield firehose.createDeliveryStream({
                DeliveryStreamName: streamName,
                DeliveryStreamType: "DirectPut",
                S3DestinationConfiguration: {
                    Prefix: streamPrefix,
                    ErrorOutputPrefix: streamErrorPrefix,
                    BucketARN: `arn:aws:s3:::${UserBucket}`,
                    RoleARN: RoleArn
                },
                Tags: [
                    { Key: "Stage", Value: stage },
                    { Key: "ServiceName", Value: ServiceName },
                    { Key: "TenantId", Value: tenantId },
                    { Key: "FormId", Value: formId }
                ]
            }).promise();
            console.log(`${ServiceName} - createstream.handle created delivery stream ${streamName}`);
            callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "OK", status: 202, id: requestId, timestamp: requestTime }) });
        }
        else {
            console.log(`${ServiceName} - createstream.handle delivery stream already exists ${streamName}`);
            callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "OK", status: 304, id: requestId, timestamp: requestTime }) });
        }
    }
    catch (e) {
        console.log(`${ServiceName} - createstream.handle ERROR creating Stream ${streamName}`, e);
        callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "InternalServerError", status: 500, requestId: requestId }) });
    }
});


/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "aws-xray-sdk":
/*!*******************************!*\
  !*** external "aws-xray-sdk" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ }),

/***/ "uuid/v4":
/*!**************************!*\
  !*** external "uuid/v4" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("uuid/v4");

/***/ })

/******/ })));
//# sourceMappingURL=createstream.js.map