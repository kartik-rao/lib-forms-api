(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./functions/createstream.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./functions/common.ts":
/*!*****************************!*\
  !*** ./functions/common.ts ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const short_uuid_1 = __importDefault(__webpack_require__(/*! short-uuid */ "short-uuid"));
const uuidTranslator = short_uuid_1.default();
function getDeliveryStreamName(stage, tenantId, formId) {
    return `${stage}-stream-${uuidTranslator.fromUUID(tenantId)}-${uuidTranslator.fromUUID(formId)}`;
}
exports.getDeliveryStreamName = getDeliveryStreamName;
function getDeliveryStreamPrefix(tenantId, formId) {
    return `home/${tenantId}/${formId}/processed/`;
}
exports.getDeliveryStreamPrefix = getDeliveryStreamPrefix;
function getDeliveryStreamErrorPrefix(tenantId, formId) {
    return `home/${tenantId}/${formId}/error/`;
}
exports.getDeliveryStreamErrorPrefix = getDeliveryStreamErrorPrefix;


/***/ }),

/***/ "./functions/createstream.ts":
/*!***********************************!*\
  !*** ./functions/createstream.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=./createstream.js.map
__webpack_require__(/*! source-map-support */ "source-map-support").install();
process.env.TZ = 'UTC';
const aws_sdk_1 = __importDefault(__webpack_require__(/*! aws-sdk */ "aws-sdk"));
const aws_xray_sdk_1 = __importDefault(__webpack_require__(/*! aws-xray-sdk */ "aws-xray-sdk"));
const common_1 = __webpack_require__(/*! ./common */ "./functions/common.ts");
const AWS = aws_xray_sdk_1.default.captureAWS(aws_sdk_1.default);
const Region = process.env.region;
const ServiceName = process.env.serviceName;
const UserBucket = process.env.s3_user_bucket;
const RoleArn = process.env.kinesisAccessRole;
const DBClusterId = process.env.dbClusterArn;
const DBSecretARN = process.env.dbClusterSecretArn;
const DatabaseName = process.env.databaseName;
const CORS_HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Content-Type": "application/json"
};
exports.handle = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    if (!event.requestContext.authorizer || !event.requestContext.authorizer.claims) {
        console.error(new Error("NoAuth"));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "Unauthorized", status: 401 }) });
        return;
    }
    let claims = event.requestContext.authorizer.claims;
    console.log(`${ServiceName} - createstream.handle - auth claims`, JSON.stringify(claims));
    let group = claims["custom:group"];
    if (!group || group.length == 0) {
        console.error(new Error("NoGroup"));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden", status: 403 }) });
        return;
    }
    if (!(group == "AccountEditor" || group == "Admin" || group == "AccountAdmin")) {
        console.error(new Error(`Group ${group} is not authorized to create stream`));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "Forbidden", status: 403 }) });
        return;
    }
    let tenantId = group == "Admin" ? event.queryStringParameters.tenantId : claims["custom:tenantId"];
    if (!tenantId) {
        console.error(new Error(`NoTenantId`));
        callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "BadRequest", status: 400 }) });
        return;
    }
    let { requestId, stage, requestTime } = event.requestContext;
    let { formId } = event.pathParameters;
    try {
        const rds = new AWS.RDSDataService();
        const checkFormInTenant = {
            database: DatabaseName,
            resourceArn: DBClusterId,
            secretArn: DBSecretARN,
            sql: `SELECT COUNT(*) AS form_count FROM Form WHERE id=:id AND accountId=:accountId`,
            parameters: [
                { name: "id", value: { stringValue: formId } },
                { name: "accountId", value: { stringValue: tenantId } },
            ]
        };
        console.log(`${ServiceName} - createstream.handle - rds-checkForm REQ`);
        let countResponse = yield rds.executeStatement(checkFormInTenant).promise();
        console.log(`${ServiceName} - createstream.handle - rds-checkForm RES`, JSON.stringify(countResponse.records));
        if (countResponse.records[0][0]['longValue'] == 0) {
            console.error(new Error("InvalidFormId"));
            callback(null, { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ "message": `Form [${formId}] not found in tenant [${tenantId}]` }) });
            return;
        }
    }
    catch (error) {
        console.error(error);
        callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "InternalServerError" }) });
    }
    let firehose = new AWS.Firehose({ region: Region });
    const streamName = common_1.getDeliveryStreamName(stage, tenantId, formId);
    const streamPrefix = common_1.getDeliveryStreamPrefix(tenantId, formId);
    const streamErrorPrefix = common_1.getDeliveryStreamErrorPrefix(tenantId, formId);
    try {
        let streams = yield firehose.listDeliveryStreams({ ExclusiveStartDeliveryStreamName: streamName.substring(0, streamName.length - 1) }).promise();
        if (!streams.DeliveryStreamNames || streams.DeliveryStreamNames.length == 0) {
            yield firehose.createDeliveryStream({
                DeliveryStreamName: streamName,
                DeliveryStreamType: "DirectPut",
                S3DestinationConfiguration: {
                    Prefix: streamPrefix,
                    ErrorOutputPrefix: streamErrorPrefix,
                    BucketARN: `arn:aws:s3:::${UserBucket}`,
                    RoleARN: RoleArn,
                    CloudWatchLoggingOptions: {
                        Enabled: true
                    }
                },
                Tags: [
                    { Key: "Application", Value: "formsli" },
                    { Key: "Name", Value: streamName },
                    { Key: "Environment", Value: stage },
                    { Key: "Stack", Value: ServiceName },
                    { Key: "Deployer", Value: ServiceName },
                    { Key: "TenantId", Value: tenantId },
                    { Key: "FormId", Value: formId }
                ]
            }).promise();
            console.log(`${ServiceName} - createstream.handle created delivery stream ${streamName}`);
            callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "OK", status: 202, id: requestId, timestamp: requestTime }) });
        }
        else {
            console.log(`${ServiceName} - createstream.handle delivery stream already exists ${streamName}`);
            callback(null, { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ message: "OK", status: 304, id: requestId, timestamp: requestTime }) });
        }
    }
    catch (e) {
        console.log(`${ServiceName} - createstream.handle ERROR creating Stream ${streamName}`, e);
        callback(null, { statusCode: 500, headers: CORS_HEADERS, body: JSON.stringify({ message: "InternalServerError", status: 500, requestId: requestId }) });
    }
});


/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),

/***/ "aws-xray-sdk":
/*!*******************************!*\
  !*** external "aws-xray-sdk" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),

/***/ "short-uuid":
/*!*****************************!*\
  !*** external "short-uuid" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("short-uuid");

/***/ }),

/***/ "source-map-support":
/*!*************************************!*\
  !*** external "source-map-support" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("source-map-support");

/***/ })

/******/ })));
//# sourceMappingURL=createstream.js.map